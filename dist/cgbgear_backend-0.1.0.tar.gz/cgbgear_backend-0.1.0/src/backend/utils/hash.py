# -*- coding: utf-8 -*-
#  Copyright (C) 2026 FjiNeko
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#  You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import hashlib
import os

def hash_password(password):
    """
    使用 SHA256 加盐哈希处理密码。
    建议生产环境使用更强的库如 bcrypt 或 argon2-cffi。
    """
    # 生产环境中，盐值应随机生成并存储在数据库中，或从安全配置读取。
    # 这里为了简化示例，使用一个固定盐。
    salt = os.getenv("PASSWORD_SALT", "cgbgear_backend_salt_secret") 
    return hashlib.sha256((password + salt).encode()).hexdigest()

def check_password(stored_hash, input_password):
    """验证密码是否正确"""
    return stored_hash == hash_password(input_password)
